#ifndef GAME_H
#define GAME_H
#include <QWidget>
#include <QLabel>
#include <QHBoxLayout>
#include <QGraphicsView>
#include <QPushButton>
#include <QMouseEvent>
#include <QVector>
#include <QMediaPlayer>

namespace Ui {
class Form;
}


class game: public QWidget
{
    Q_OBJECT
public:
    explicit game(QWidget *parent = nullptr);
    QPushButton* select_hole(int num);
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void set_all_holes_empty();
    int generate_color_not_equal_to(int color);
    int generate_index_not_equal_to(int index1, int index2);
    void music_play();
    ~game();

signals:

public slots:

    //select random holes to generate mouse
    void generate_mouse();
    void mouse_appear_animation_1();
    void mouse_appear_animation_2();
    void mouse_appear_animation_3();

    // the "3, 2, 1, start" count down
    void countdown();

    void custom_song();

    //show prompt mouse for the user
    void prompt();

    void quit();
    void resume();

    //start the whole game
    void time();

    //show you win or lose
    void win_lose_display();

    //change the song
    void change_song();

    //show the database of song
    void show_table();


    //button for holes are pushed
    void press_1();
    void press_2();
    void press_3();
    void press_4();
    void press_5();
    void press_6();
    void press_7();
    void press_8();
    void press_9();

    // button for holes are released
    void release_1();
    void release_2();
    void release_3();
    void release_4();
    void release_5();
    void release_6();
    void release_7();
    void release_8();
    void release_9();


private slots:
    void on_dial_valueChanged(int value);

private:
    QTimer *timer = nullptr;
    QTimer *timer_2;
    //timer used for mouse appear
    QTimer *animation_timer_1;
    QTimer *animation_timer_2;
    QTimer *animation_timer_3;
    //timer for prompt button
    QTimer *prompt_timer;

    Ui::Form *ui;

    int time_lapse;
    int time_lapse_prompt = 2000;
    int time_lapse_animation = 200;
    int display_num = 3; //set it initially to be 3
    int pos = 0;
    int note = 0;
    int prompt_pos = 0;
    int appear_stage_1 = 0;
    int appear_stage_2 = 0;
    int appear_stage_3 = 0;
    int correct_button_index = 0;
    int wrong_button_index_1 = 0;
    int wrong_button_index_2 = 0;
    int other_color_1;
    int other_color_2;
    QVector<int> currentSong;
    const QVector<int> Song_1 = {1,2,3};
    const QVector<int> Song_2 = {1,1,5,5,6,6,5,4,4,3,3,2,2,1,5,5,4,4,3,3,2,5,5,4,4,3,3,2,1,1,5,5,6,6,5,4,4,3,3,2,2,1} ;
    const QVector<int> Song_3 = {3,3,4,5,5,4,3,2,1,1,2,3,3,2,2,3,3,4,5,5,4,3,2,1,1,2,3,2,1,1};
    QVector<QVector<int>> all_song = {Song_1,Song_2,Song_3};
    QVector<QString> song_name = {"running scale", "little star", "ode to joy"};
    QMap<QString, QString> mapSongs;
    QVector<int> highest_score = {0,0,0};
    QPushButton* mouse_correct_button;
    QPushButton* mouse_1_button;
    QPushButton* mouse_2_button;
    bool check_1;
    bool check_2;
    bool check_3;
    bool game_over = false;
    int pos_of_name = 0;
    int score = 0;
    int num_of_custom = 0;
    bool table = true;

    //count if all hit correct
    int check_correct = 0;
    // pos of song
    int song_pos = 0;
};
#endif // GAME_H
