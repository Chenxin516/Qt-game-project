#ifndef HOLDINGWIDGET_H
#define HOLDINGWIDGET_H

#include <QWidget>
#include <QStackedWidget>
#include <QLayout>
#include <QPushButton>
#include "dialog.h"
#include "game.h"
#include "instruction.h"


class holdingwidget: public QWidget
{
    Q_OBJECT
public:
    explicit holdingwidget(QWidget *parent = nullptr);

signals:

public slots:
    void DisplayDialog();
    void DisplayGame();
    void DisplayInstruction();

private:
    QStackedWidget* widget_holder = nullptr;
    QVBoxLayout* main_layout = nullptr;
    QPushButton* dialog_window_button = nullptr;
    QPushButton* game_window_button = nullptr;
    Dialog* first_win = nullptr;
    game* second_win = nullptr;
    instruction* third_win = nullptr;
    QMediaPlayer* music =nullptr;
};

#endif // HOLDINGWIDGET_H
