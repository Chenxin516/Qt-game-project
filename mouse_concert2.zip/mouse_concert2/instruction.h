#ifndef INSTRUCTION_H
#define INSTRUCTION_H

#include "QWidget"

class instruction: public QWidget
{    
    Q_OBJECT
public:
    explicit instruction(QWidget *parent = 0);
    ~instruction(){}
};

#endif // INSTRUCTION_H
